'use strict';

/**
 * @ngdoc function
 * @name saqibProjectApp.controller:ServicesCtrl
 * @description
 * # ServicesCtrl
 * Controller of the saqibProjectApp
 */
angular.module('saqibProjectApp')
  .controller('ServicesCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
