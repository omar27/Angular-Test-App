'use strict';

/**
 * @ngdoc function
 * @name saqibProjectApp.controller:RegistrationCtrl
 * @description
 * # RegistrationCtrl
 * Controller of the saqibProjectApp
 */
angular.module('saqibProjectApp')
  .controller('RegistrationCtrl', function ($scope) {
     $scope.firstName = 'John Doe';
    $scope.email = 'john.doe@gmail.com';
	$scope.catagories = ["Student", "Banker", "Software Engineer", "Doctor	"];
  });
