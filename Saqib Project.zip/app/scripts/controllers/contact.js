'use strict';

/**
 * @ngdoc function
 * @name saqibProjectApp.controller:ContactCtrl
 * @description
 * # ContactCtrl
 * Controller of the saqibProjectApp
 */
angular.module('saqibProjectApp')
  .controller('ContactCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
